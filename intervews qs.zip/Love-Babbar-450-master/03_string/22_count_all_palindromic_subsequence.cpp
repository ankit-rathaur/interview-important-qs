/*
    link: https://practice.geeksforgeeks.org/problems/count-palindromic-subsequences/1

    DP variation

    sol refer to: 14_DP/46_all_count_palindromic_subsequence.cpp

    note: currently sol. is not working in practice.gfg but its correct.
*/
